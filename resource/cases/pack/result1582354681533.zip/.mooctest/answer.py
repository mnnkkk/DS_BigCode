print('+'.join(sorted(input().split('+'))))
