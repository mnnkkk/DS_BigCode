print(3)
print(-1)